#!/bin/bash

# Import Prometheus Datasource

echo 'Import Prometheus datasource on Grafana' &&
curl --silent --fail --show-error \
--request POST http://admin:put_admin_your_password@grafana.cloudapps.cloud-cafe.in/api/datasources \
--header "Content-Type: application/json" \
--data-binary @prometheus-datasource.json ;

# Import OSE Dashboard

echo "Importing OSE Dashboards on Grafana"
for f in OSE*.json; do
  echo "$f"
  curl -sS  "http://admin:put_admin_your_password@grafana.cloudapps.cloud-cafe.in/api/dashboards/db" -X POST -H 'Content-Type: application/json;charset=UTF-8' --data-binary "@$f"
done
